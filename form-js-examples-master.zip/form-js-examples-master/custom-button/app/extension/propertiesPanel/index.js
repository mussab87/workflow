import { CustomPropertiesProvider } from './CustomPropertiesProvider';

export default {
  __init__: [ 'feedbackButtonPropertiesProvider' ],
  feedbackButtonPropertiesProvider: [ 'type', CustomPropertiesProvider ]
};