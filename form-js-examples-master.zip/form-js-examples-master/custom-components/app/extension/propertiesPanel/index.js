import { CustomPropertiesProvider } from './CustomPropertiesProvider';

export default {
  __init__: [ 'rangePropertiesProvider' ],
  rangePropertiesProvider: [ 'type', CustomPropertiesProvider ]
};